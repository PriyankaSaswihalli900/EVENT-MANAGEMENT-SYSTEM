from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from PIL import Image

# Create your models here.
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    image = models.ImageField(default='__init__.png', upload_to='profile_pics')


    def __str__(self):
        return f'{self.user.username} Profile'



class show(models.Model):
    name = models.CharField(max_length=50)
    venue = models.CharField(max_length=200)
    startdate = models.DateField()
    enddate = models.DateField()
    starttime = models.TimeField()
    endtime = models.TimeField()
    des = models.CharField(max_length=300)
    num_of_attendees = models.PositiveIntegerField(default=0, blank=True)
    image = models.ImageField(upload_to='events/images', default="")
    TECNICALFEST = 'Tecnical fest'
    CULTURALFEST = 'Cultural fest'
    LITERATUEFEST = 'Litarure fest'
    MANAGMENTFEST = 'Management fest'
    WORKSHOP = 'Workshop'
    CONFERANCE = 'Conferance'
    SEMINAR = 'Seminar'
    PRONIGHT = 'Pronight'
    Event_Choice = (
        (TECNICALFEST, 'Tecnical fest'),
        (CULTURALFEST, 'Cultural fest'),
        (LITERATUEFEST, 'Litarure fest'),
        (MANAGMENTFEST, 'Management fest'),
        (WORKSHOP, 'Workshop'),
        (CONFERANCE, 'Conferance'),
        (SEMINAR, 'Seminar'),
        (PRONIGHT, 'Pronight'),
    )
    event_in_collage = models.CharField(
        max_length=20,
        choices=Event_Choice
    )
    pdf =   models.FileField(upload_to='events/file', default="")



    def __str__(self):
        return self.name


    def get_absolute_url(self):
        return reverse('show_edit', kwargs={'pk': self.pk})


class studentregister(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField(max_length=50)
    city = models.CharField(max_length=50)
    TECNICALFEST = 'Tecnical fest'
    CULTURALFEST = 'Cultural fest'
    LITERATUEFEST = 'Litarure fest'
    MANAGMENTFEST = 'Management fest'
    WORKSHOP = 'Workshop'
    CONFERANCE = 'Conferance'
    SEMINAR = 'Seminar'
    PRONIGHT = 'Pronight'
    Student_interset = (
        (TECNICALFEST, 'Tecnical fest'),
        (CULTURALFEST, 'Cultural fest'),
        (LITERATUEFEST, 'Litarure fest'),
        (MANAGMENTFEST, 'Management fest'),
        (WORKSHOP, 'Workshop'),
        (CONFERANCE, 'Conferance'),
        (SEMINAR, 'Seminar'),
        (PRONIGHT, 'Pronight'),
    )
    Student_interset = models.CharField(
        max_length=20,
        choices=Student_interset
    )
    MCA = 'M.C.A'
    MBA = 'M.B.A'
    MSE = 'M.S.E'
    MECHANICAL = 'Mechanical'
    CIVIL = 'Civil'
    ELECTRICAL = 'Electrical'
    COMPUTERSCIENCE = 'Computerscience'
    BCA = 'B.C.A'
    Department = (
        (MCA, 'M.C.A'),
        (MBA, 'M.B.A'),
        (MSE, 'M.S.E'),
        (MECHANICAL, 'Mechanical'),
        (CIVIL, 'Civil'),
        (ELECTRICAL, 'Electrical'),
        (COMPUTERSCIENCE, 'Computerscience'),
        (BCA, 'B.C.A'),
    )
    Department = models.CharField(
        max_length=20,
        choices=Department
    )


    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('studentregister_edit', kwargs={'pk': self.pk})


class prize(models.Model):
    firstprize = '1st prize'
    secondprize = '2nd prize'
    thirdprize = '3rd prize'
    student_prize = (
        (firstprize, '1st prize'),
        (secondprize, '2nd prize'),
        (thirdprize,'3rd prize'),
    )
    student_prize = models.CharField(
        max_length=20,
        choices=student_prize
    )
    name = models.CharField(max_length=50)
    TECNICALFEST = 'Tecnical fest'
    CULTURALFEST = 'Cultural fest'
    LITERATUEFEST = 'Litarure fest'
    MANAGMENTFEST = 'Management fest'
    WORKSHOP = 'Workshop'
    CONFERANCE = 'Conferance'
    SEMINAR = 'Seminar'
    PRONIGHT = 'Pronight'
    prize_interset = (
        (TECNICALFEST, 'Tecnical fest'),
        (CULTURALFEST, 'Cultural fest'),
        (LITERATUEFEST, 'Litarure fest'),
        (MANAGMENTFEST, 'Management fest'),
        (WORKSHOP, 'Workshop'),
        (CONFERANCE, 'Conferance'),
        (SEMINAR, 'Seminar'),
        (PRONIGHT, 'Pronight'),
    )
    prize_interset= models.CharField(
        max_length=20,
        choices=prize_interset
    )
    MCA = 'M.C.A'
    MBA = 'M.B.A'
    MSE = 'M.S.E'
    MECHANICAL = 'Mechanical'
    CIVIL = 'Civil'
    ELECTRICAL = 'Electrical'
    COMPUTERSCIENCE = 'Computerscience'
    BCA = 'B.C.A'
    prize_Department = (
        (MCA, 'M.C.A'),
        (MBA, 'M.B.A'),
        (MSE, 'M.S.E'),
        (MECHANICAL, 'Mechanical'),
        (CIVIL, 'Civil'),
        (ELECTRICAL, 'Electrical'),
        (COMPUTERSCIENCE, 'Computerscience'),
        (BCA, 'B.C.A'),
    )
    prize_Department = models.CharField(
        max_length=20,
        choices=prize_Department
    )

    def __str__(self):
        return self.prize_interset
