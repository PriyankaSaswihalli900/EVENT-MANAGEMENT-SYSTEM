from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Profile
from .models import User, show, studentregister, prize


class UserRegisterForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, required=False, help_text='Optional.')
    last_name = forms.CharField(max_length=30, required=False, help_text='Optional.')
    email = forms.EmailField(max_length=254, help_text='Required. Inform a valid email address.')

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']


class UserUpdateForm(forms.ModelForm):
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'email']


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['image']
#
#
# class student_form(forms.ModelForm):
#     name = forms.CharField(max_length=50, required=True)
#     email = forms.EmailField(max_length=50, required=True)
#     city = forms.CharField(max_length=50,  required=True)
#
#     class Meta():
#         model = studentregister
#         fields = ['name','email', 'city', 'Student_interset', 'Department']


class prize_form(forms.ModelForm):
    name = forms.CharField(max_length=50, required=True)
    class Meta():
        model = prize
        fields = ['student_prize','name','prize_Department',  'prize_interset']















