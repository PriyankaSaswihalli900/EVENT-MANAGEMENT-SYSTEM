from django.shortcuts import render, redirect,get_object_or_404
from django.contrib import messages
from django.http import *
from django.http import HttpResponse
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.http import HttpResponse
from django.contrib.auth.views import login_required
from .forms import UserRegisterForm, UserUpdateForm, ProfileUpdateForm, prize_form
from .models import show, Profile, studentregister, prize
from django.contrib.auth.models import User

def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important!
            messages.success(request, 'Your password was successfully updated!')
            return redirect('change_password')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'users/change_password.html', {
        'form': form
    })
def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, f'Your account has been created! You are now able to log in')
            return redirect('indexhome')

    else:
        form = UserRegisterForm()
    return render(request, 'users/register.html', {'form4': form})

@login_required
def profile(request):
    if request.method == 'POST':
        u_form = UserUpdateForm(request.POST, instance=request.user)
        p_form = ProfileUpdateForm(request.POST,
                                   request.FILES,
                                   instance=request.user.profile)
        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            messages.success(request, f'Your account has been updated!')
            return redirect('profile')

    else:
        u_form = UserUpdateForm(instance=request.user)
        p_form = ProfileUpdateForm(instance=request.user.profile)

    context = {
        'u_form': u_form,
        'p_form': p_form
    }

    return render(request, 'users/profile.html', context)

def pro(request):
    products = show.objects.all()
    print(products)
    n = len(products)
    params = {'no_of_slides': n, 'range': range(1, n), 'product': products}
    return render(request, 'users/pro.html', params)


def prize1(request):
    if request.method == 'POST':
        form = prize_form(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'prizeform is succesfully submitted')
            return HttpResponseRedirect('/prizeform/')
    else:
        form = prize_form()
    return render(request, 'users/prize.html', {'form3': form})


def prizelist(request):
    products = prize.objects.all()
    print(products)
    n = len(products)
    params = {'no_of_slides': n, 'range': range(1, n), 'prizelist': products}
    return render(request, 'users/prizelist.html', params)


def pro(request):
    pro = show.objects.all()
    print(pro)
    n = len(pro)
    params = {'no_of_slides': n, 'range': range(1, n), 'pro': pro}
    return render(request, 'users/pro.html', params)

class showList(ListView):
    model = show


class showView(DetailView):
    model = show

class showCreate(CreateView):
    model = show
    fields = ['name', 'venue','startdate', 'enddate','starttime', 'endtime','des', 'num_of_attendees','image', 'event_in_collage','pdf']
    success_url = reverse_lazy('show_list')

class showUpdate(UpdateView):
    model = show
    fields = ['name', 'venue','startdate', 'enddate','starttime', 'endtime','des', 'num_of_attendees','image', 'event_in_collage','pdf']
    success_url = reverse_lazy('show_list')

class showDelete(DeleteView):
    model = show
    success_url = reverse_lazy('show_list')




class studentregisterList(ListView):
    model = studentregister


class studentregisterView(DetailView):
    model = studentregister

class studentregisterCreate(CreateView):
    model = studentregister
    fields = ['name', 'email','city', 'Student_interset','Department']
    success_url = reverse_lazy('studentregister_list')

class studentregisterUpdate(UpdateView):
    model = studentregister
    fields = ['name', 'email','city', 'Student_interset','Department']
    success_url = reverse_lazy('studentregister_list')

class studentregisterDelete(DeleteView):
    model = studentregister
    success_url = reverse_lazy('studentregister_list')