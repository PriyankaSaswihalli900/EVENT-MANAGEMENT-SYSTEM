"""cem URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from users import views as user_views
from django.contrib.auth import views as auth_views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('home.urls')),
    path('login/', auth_views.LoginView.as_view(template_name='users/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(template_name='users/logout.html'), name='logout'),
    path('register/', user_views.register, name='register'),
    path('eventlist/', user_views.pro, name='pro'),
url(r'^password/$', user_views.change_password, name='change_password'),
    path('password_change/', auth_views.PasswordChangeView.as_view(template_name='users/password_reset_form.html'), name='password_change'),
    path('profile/', user_views.profile, name='profile'),
    path('prizeform/',user_views.prize1, name = 'prize1'),
    path('prizelist/', user_views.prizelist, name='prizelist'),
    url('^', include('django.contrib.auth.urls')),
    path('list/', user_views.showList.as_view(), name='show_list'),
    path('view/<int:pk>', user_views.showView.as_view(), name='show_view'),
    path('new', user_views.showCreate.as_view(), name='show_new'),
    path('view/<int:pk>', user_views.showView.as_view(), name='show_view'),
    path('edit/<int:pk>', user_views.showUpdate.as_view(), name='show_edit'),
    path('delete/<int:pk>', user_views.showDelete.as_view(), name='show_delete'),

    path('studentregister/', user_views.studentregisterList.as_view(), name='studentregister_list'),
    path('view1/<int:pk>', user_views.studentregisterView.as_view(), name='studentregister_view1'),
    path('new1/', user_views.studentregisterCreate.as_view(), name='studentregister_new1'),
    path('view1/<int:pk>', user_views.studentregisterView.as_view(), name='studentregister_view1'),
    path('edit1/<int:pk>', user_views.studentregisterUpdate.as_view(), name='studentregister_edit1'),
    path('delete1/<int:pk>', user_views.studentregisterDelete.as_view(), name='studentregister_delete1'),


]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

