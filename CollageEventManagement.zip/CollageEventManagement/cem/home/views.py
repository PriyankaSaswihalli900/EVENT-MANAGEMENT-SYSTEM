from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import event
from django.shortcuts import render

from . models import event
from math import ceil

def index(request):
    prod = event.objects.all()
    print(prod)
    n = len(prod)
    params = {'no_of_slides': n, 'range': range(0, n), 'prod': prod}
    return render(request, 'shop/index.html', params)


def about(request):
    return render(request, 'shop/about.html')





